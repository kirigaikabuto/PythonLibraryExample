def sum_of_two(a, b):
    return a+b